from microbit import *
import random
import speech
speaker.on()

while True:
    if button_a.is_pressed():
        word1number = (random.randint(1, 4))
        if word1number == 1:
            word1 = 'Eye'
        elif word1number == 2:
            word1 = 'You'
        else:
            word1 = 'day'
        word2number = (random.randint(1,4))
        if word2number == 1:
            word2 = 'will'
        elif word2number == 2:
            word2 = 'must'
        elif word2number == 3:
            word2 = "don't know how to"
        else:
            word2 = 'have to'
        word3number = (random.randint(1, 5))
        if word3number == 1:
            word3 = 'go to the toilet'
        elif word3number == 2:
            word3 = 'go to my locker'
        elif word3number == 3:
            word3 = 'use this'
        elif word3number == 4:
            word3 = 'go home'
        else:
            word3 = 'stuhdie'
        speech.say(word1)
        speech.say(word2)
        speech.say(word3)