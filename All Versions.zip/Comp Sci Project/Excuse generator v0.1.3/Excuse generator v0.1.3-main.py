import speech

line1 = "We're no strangers to love."
line2 = "You know the roolz and so do I, do I."
line3 = "A full commitment's what I'm thinking of."
line4 = "You wouldn't get this from any other guy."
line5 = "I just wanna tell you how I'm feeling."
line6 = "Gotta make you understand."
verse1 = "Never gonna give you up."
verse2 = "Never gonna let you down."
verse3 = "Never gonna run around and desert you."
verse4 = "Never gonna make you cry."
verse5 = "Never gonna say goodbuy."
verse6 = "Never gonna tell a lie and hurt you."
line11 = "We've known each other for so long."
line12 = "Your haart's been ayking, but your too shy to say it, say it."
line13 = "Insaide, we both know what's been going on, going on."
line14 = "We know the game and we're gonna play it."
line15 = "And if you ask me how I'm feeling."
line16 = "Don't tell me you're too blind to see."

speech.say(line1)
speech.say(line2)
speech.say(line3)
speech.say(line4)
speech.say(line5)
speech.say(line6)
speech.say(verse1)
speech.say(verse2)
speech.say(verse3)
speech.say(verse4)
speech.say(verse5)
speech.say(verse6)
speech.say(line11)
speech.say(line12)
speech.say(line13)
speech.say(line14)
speech.say(line15)
speech.say(line16)
speech.say(verse1)
speech.say(verse2)
speech.say(verse3)
speech.say(verse4)
speech.say(verse5)
speech.say(verse6)
speech.say(verse1)
speech.say(verse2)
speech.say(verse3)
speech.say(verse4)
speech.say(verse5)
speech.say(verse6)
speech.say(line11)
speech.say(line12)
speech.say(line13)
speech.say(line14)
speech.say(line15)
speech.say(line16)
speech.say(verse1)
speech.say(verse2)
speech.say(verse3)
speech.say(verse4)
speech.say(verse5)
speech.say(verse6)
speech.say(verse1)
speech.say(verse2)
speech.say(verse3)
speech.say(verse4)
speech.say(verse5)
speech.say(verse6)
speech.say(verse1)
speech.say(verse2)
speech.say(verse3)
speech.say(verse4)
speech.say(verse5)
speech.say(verse6)